package com.example.demo.employee.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeEntity {
	private String id;
	private String name;
}
