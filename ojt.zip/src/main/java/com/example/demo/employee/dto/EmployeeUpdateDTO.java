package com.example.demo.employee.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeUpdateDTO {
	//����
	private String empNm;
	private String deptId;
	private String telNo;
	private String addr;
}
